<div style="display: table; width: 100%; height: 250px;">
	<div class="ejemplo" style="display: table-cell; height: 100%; vertical-align: middle;">
		<div class="centrada" style="width: 50%; margin: 0 auto;">
			<form id="flogin" name="flogin" method="post">
				<label>
					<h4>Login</h4>
					<input type="text" id="login" name="login" value="">
				</label>
				<label>
					<h4>Contrase&ntilde;a</h4>
					<input type="password" id="pass" name="pass" value="">
				</label>
				<br><br>
				<input class="w3-btn w3-dulcevanidad" type="submit" id="enviar" name="enviar" value="Entrar">
			</form>
		</div>
	</div>
</div>